import React from "react";

function Header() {
    return (
        <div className='header'>
            <h1 className='title'>리액트구현</h1>
        </div>
    )
}

export default Header;