import React from "react";

function Delivery() {
    return (
        <div>
            <div className="subimg">Delivery</div>
            <div className="contents">contents</div>
        </div>
    )
}

export default Delivery;
