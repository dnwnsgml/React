import React from "react";
import ContentsItem from "./contents_item";

function Contents() {
    return (
        <div className='contents'>
            <ContentsItem />
            <ContentsItem />
            <ContentsItem />
            <ContentsItem />
            <ContentsItem />
            <ContentsItem />
        </div>
    )
}

export default Contents;