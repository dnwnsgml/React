import React from "react";

function Market() {
    return (
        <div>
            <div className="subimg">Market</div>
            <div className="contents">contents</div>
        </div>
    )
}

export default Market;
