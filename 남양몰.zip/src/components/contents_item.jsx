import React from "react";

function ContentsItem() {
    return (
        <div className="ContentsItem" style={{ margin: '0 auto', width: '1100px', height: '200px' }}>
            <div className="header">
                <h3> ContentsItme</h3>
            </div>
            <div className="body">
                <p>ContentsItme</p>
            </div>
        </div>
    )
}

export default ContentsItem;