import React from "react";

function Pop() {
    return (
        <div>
            <div className="subimg">Pop</div>
            <div className="contents">contents</div>
        </div>
    )
}

export default Pop;
